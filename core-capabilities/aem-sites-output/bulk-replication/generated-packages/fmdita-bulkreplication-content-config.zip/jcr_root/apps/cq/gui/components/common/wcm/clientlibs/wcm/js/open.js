/*
 ADOBE CONFIDENTIAL

 Copyright 2014 Adobe Systems Incorporated
 All Rights Reserved.

 NOTICE:  All information contained herein is, and remains
 the property of Adobe Systems Incorporated and its suppliers,
 if any.  The intellectual and technical concepts contained
 herein are proprietary to Adobe Systems Incorporated and its
 suppliers and may be covered by U.S. and Foreign Patents,
 patents in process, and are protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material
 is strictly forbidden unless prior written permission is obtained
 from Adobe Systems Incorporated.
 */
(function(window, document, $, URITemplate, CUI) {
    "use strict";

    $(window).adaptTo("foundation-registry").register("foundation.collection.action.action", {
        name: "cq.wcm.open",
        handler: function(name, el, config, collection, selections) {
            // if touch device, set editing cookie first
            if (CUI.util.isTouch) {
                $.cookie("cq-authoring-mode", "TOUCH", {
                    path: config.data.cookiePath,
                    expires: 7
                });
            }
            
            var winMode = $("meta[name='user.preferences.winmode']", document.head).prop("content");
            
            if (winMode === "single") {
                var first = selections[0];
                if (first) {
                    var url = URITemplate.expand(config.data.href, {
                        item: $(first).data("foundation-collection-item-id")
                    });
                    
                    window.location.href = url;
                }
            } else {
                selections.forEach(function(item) {
                    var url = URITemplate.expand(config.data.href, {
                        item: $(item).data("foundation-collection-item-id")
                    });
                    
                    window.open(url);
                });
            }
        }
    });
})(window, document, Granite.$, Granite.URITemplate, CUI);
