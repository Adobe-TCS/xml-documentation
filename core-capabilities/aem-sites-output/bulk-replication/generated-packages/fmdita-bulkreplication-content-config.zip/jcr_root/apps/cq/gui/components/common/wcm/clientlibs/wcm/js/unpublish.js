/*
 ADOBE CONFIDENTIAL

 Copyright 2014 Adobe Systems Incorporated
 All Rights Reserved.

 NOTICE:  All information contained herein is, and remains
 the property of Adobe Systems Incorporated and its suppliers,
 if any.  The intellectual and technical concepts contained
 herein are proprietary to Adobe Systems Incorporated and its
 suppliers and may be covered by U.S. and Foreign Patents,
 patents in process, and are protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material
 is strictly forbidden unless prior written permission is obtained
 from Adobe Systems Incorporated.
 */
(function(window, $, URITemplate) {
    var ui = $(window).adaptTo("foundation-ui");
    var treeURL = Granite.HTTP.externalize("/bin/wcm/siteadmin/tree.json");
    var replicateURL = Granite.HTTP.externalize("/bin/replicate");
    var NUM_CHILDREN_CHECK = 20;
    var successMessage = Granite.I18n.get("The item has been unpublished");

    function unpublish(paths, collection) {
        $.ajax({
            url: replicateURL,
            type: "POST",
            data: {
                _charset_: "utf-8",
                cmd: "Deactivate",
                path: paths
            }
        }).always(function() {
            ui.clearWait();
        }).done(function() {
            var api = collection.adaptTo("foundation-collection");
            if (api && "reload" in api) {
                api.reload();
                ui.notify(null, successMessage);
                return;
            }
            
            var contentApi = $(".foundation-content").adaptTo("foundation-content");
            if (contentApi) {
                contentApi.refresh();
            }
            
            ui.notify(null, successMessage);
        }).fail(function(xhr) {
            var title = Granite.I18n.get("Error");
            var message = Granite.I18n.getVar($(xhr.responseText).find("#Message").html());
            ui.alert(title, message, "error");
        });
    }
    
    function countReferences(config, paths) {
        return $.ajax({
            url: URITemplate.expand(config.data.referenceSrc, {
                path: paths,
                predicate: "wcmcontent"
            }),
            "type": "POST",
            cache: false,
            dataType: "json"
        }).then(function(json) {
            return json.pages.reduce(function(memo, value) {
                if (value.published && (value.isPage === true || value.isPage === "true") && value.path !== value.srcPath) {
                    return memo + 1;
                }
                return memo;
            }, 0);
        });
    }
    
    /**
     * Returns the promise of the total count of the descendants of the given paths.
     * 
     * The promise is rejected when both the total is "0" and there is an error.
     * i.e. when we are not sure if there is at least a descendant or not.
     */
    function countChildren(paths) {
        var total = 0;
        
        var promises = paths.map(function(path) {
            return $.ajax({
                url: treeURL,
                data: {
                    path: path,
                    ncc: NUM_CHILDREN_CHECK
                },
                cache: false,
                dataType: "json"
            }).then(function(children) {
                total += children.length;
                
                children.forEach(function(child) {
                    if (!child.leaf) {
                        total += child.sub;
                    }
                });
                
                return true;
            }, function() {
                return $.when(false);
            });
        });
        
        return $.when.apply(null, promises).then(function() {
            if (total > 0) {
                return total;
            }
            
            var allOK = Array.prototype.every.call(arguments, function(status) {
                return status;
            });
            
            if (allOK) {
                return total;
            }
            
            return $.Deferred().reject().promise();
        });
    }
    
    $(window).adaptTo("foundation-registry").register("foundation.collection.action.action", {
        name: "cq.wcm.unpublish",
        handler: function(name, el, config, collection, selections) {
            var ui = $(window).adaptTo("foundation-ui");
            ui.wait();

            var paths = selections.map(function(v) {
                var item = $(v);
                
                return item.data("foundationCollectionItemId");
            });

            if (!paths.length) return;
            
            // flatten the array
            paths = [].concat.apply([], paths);
            
            var countChildrenPromise = countChildren(paths);
            var countRefsPromise = countReferences(config, paths);
            
            countChildrenPromise.fail(function() {
                ui.clearWait();

                var title = Granite.I18n.get("Error");
                var message = Granite.I18n.get("Failed to retrieve child items for selected items.");
                ui.alert(title, message, "error");
            });
            
            countRefsPromise.fail(function() {
                ui.clearWait();

                var title = Granite.I18n.get("Error");
                var message = Granite.I18n.get("Failed to retrieve references for selected items.");
                ui.alert(title, message, "error");
            });
            
            $.when(countChildrenPromise, countRefsPromise).then(function(countChildren, countRefs) {
                if (countRefs === 0 && countChildren === 0) {
                    unpublish(paths, $(collection));
                    return;
                }
                
                ui.clearWait();

                if (countChildren > NUM_CHILDREN_CHECK) {
                    countChildren = NUM_CHILDREN_CHECK + "+";
                }
                
                var messageRefs = countRefs === 0 ? "" : Granite.I18n.get("Selected items are referenced by {0} item(s).", countRefs);
                var messageChildren  = countChildren === 0 ? "" : Granite.I18n.get("Upon unpublishing, other {0} child item(s) will get unpublished.", countChildren);
                var message = messageRefs + " <br> " + messageChildren;
                
                ui.prompt(Granite.I18n.get("Unpublish"), message, "notice", [{
                    text: Granite.I18n.get("Cancel")
                }, {
                    text: Granite.I18n.get("Continue"),
                    warning: true,
                    handler: function() {
                        ui.wait();
                        unpublish(paths, $(collection));
                    }
                }]);
            });
        }
    });
}(window, Granite.$, Granite.URITemplate));
