/*
 * ADOBE CONFIDENTIAL
 *
 * Copyright 2014 Adobe Systems Incorporated
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and may be covered by U.S. and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 */
(function(window, document, Granite, $) {
    "use strict";

    var COMMAND_URL= Granite.HTTP.externalize("/bin/wcmcommand");
    var ids = null;

    function closeBrowserWarning() {
        return Granite.I18n.get("Paste operation is in progress. Refreshing page may cause unexpected results.");
    }

    function updatePasteButton(context) {
        context = context || document;
        var pasteButton = $(".cq-wcm-paste-activator", context);

        if (!ids) {
            pasteButton.attr("hidden", "hidden");
            return;
        }

        pasteButton.removeAttr("hidden");
    }

    function getDestPath(activator) {
        var dest = activator.data("cqWcmPasteActivatorDest");
        
        if (dest) {
            return dest;
        }
        
        var target = activator.data("cqWcmPasteActivatorTarget");
        
        if (!target) {
            return;
        }
        
        var collection = $(target);
        
        if (!collection.hasClass("foundation-collection")) {
            return;
        }
        
        if (collection.hasClass("foundation-layout-columns")) {
            // FIXME There is a bug in foundation-layout-columns such that the [data-foundation-collection-id] is wrong when there is no active item.
            // So let's do a workaround temporarily here.
            
            var columns = collection.children(".coral-ColumnView-column");
            
            if (columns.filter(".is-active").length === 0) {
                var first = columns.first().find(".foundation-collection-item").first();
                if (first.length > 0) {
                    var id = first.data("foundationCollectionItemId");
                    var parts = id.split("/");
                    parts.pop();
                    return parts.join("/");
                }
            } else {
                return collection.data("foundationCollectionId");
            }
        } else {
            return collection.data("foundationCollectionId");
        }
    }

    function triggerPasteCompletionEvent (args, params) {

        if ($.isArray(args[0])) {
            // Multiple items pasted
            for (var i=0; i<args.length; i++) {
                var destPath = $(args[i][0]).find("#Message").html();
                params[i].destPath = destPath;
            }
        } else {
            // Single item pasted
            var destPath = $(args[0]).find("#Message").html();
            params[0].destPath = destPath;
        }

        $(document).trigger("cq-wcm-paste-completed", [params]);
    }

    $(window).adaptTo("foundation-registry").register("foundation.collection.action.action", {
        name: "cq.wcm.copy",
        handler: function(name, el, config, collection, selections) {
            ids = selections.map(function(v) {
                return $(v).data("foundationCollectionItemId");
            });

            if (!ids.length) return;

            updatePasteButton();

            $(collection).adaptTo("foundation-selections").clear();
        }
    });
    
    $(document).on("click", ".cq-wcm-paste-activator", function(e) {
        e.preventDefault();
        
        var activator = $(this);
        var destParentPath = getDestPath(activator);
        var outputParams = [];

        if (!destParentPath) {
            return;
        }
        
        var ui = $(window).adaptTo("foundation-ui");
        ui.wait();
        $(window).on("beforeunload", closeBrowserWarning);
        
        var promises = ids.map(function(v) {
            // check if we are copying a template which is stored in /conf
            var relativeTemplateParent = "settings/wcm/templates";
            if (v.indexOf("/conf") == 0
                && v.indexOf(relativeTemplateParent) > 0
                && destParentPath.indexOf(relativeTemplateParent) == -1) {
                destParentPath += "/" + relativeTemplateParent;
            }

            var outputData = {
                srcPath: v,
                destParentPath: destParentPath,
                before: "",
                shallow: false
            };
            outputParams.push(outputData);

            return $.ajax({
                url: COMMAND_URL,
                type: "POST",
                data: {
                    _charset_: "UTF-8",
                    cmd: "copyPage",
                    srcPath: v,
                    destParentPath: destParentPath,
                    before: "",
                    shallow: false
                }
            });
        });

        $.when.apply(null, promises)
            .always(function() {
                $(window).off("beforeunload", closeBrowserWarning);

                ui.clearWait();
            })
            .done(function() {

                triggerPasteCompletionEvent(arguments, outputParams);

                var target = activator.data("cqWcmPasteActivatorTarget");
                
                if (target) {
                    var api = $(target).adaptTo("foundation-collection");
                    if (api && "reload" in api) {
                        api.reload();
                        return;
                    }
                }
                
                var contentApi = $(".foundation-content").adaptTo("foundation-content");
                if (contentApi) {
                    contentApi.refresh();
                }
            }).fail(function(xhr) {
                if (xhr.status === 0 || xhr.readyState === 0) {
                    // premature reload, do nothing
                    return;
                }
                
                var title = Granite.I18n.get("Error");
                var message = Granite.I18n.getVar($(xhr.responseText).find("#Message").html());
                ui.alert(title, message, "error");
            });
    });

    $(document).on("foundation-contentloaded", function(e) { 
        updatePasteButton(e.target); 
    });

})(window, document, Granite, Granite.$);
