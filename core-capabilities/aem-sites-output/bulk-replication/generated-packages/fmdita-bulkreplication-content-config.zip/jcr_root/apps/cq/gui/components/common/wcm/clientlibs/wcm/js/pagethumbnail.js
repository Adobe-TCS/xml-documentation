/*
 * ADOBE CONFIDENTIAL
 *
 * Copyright 2012 Adobe Systems Incorporated
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and may be covered by U.S. and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 *
 */
(function(window, document, Granite, $) {
    "use strict";

    var ui = $(window).adaptTo("foundation-ui"),
        rel = ".cq-wcm-pagethumbnail",
        $assetPicker,
        $pageThumbnail;

    var contextPath = Granite.HTTP.getContextPath();

    $(document).on("reset", "form", function() {
        var component = $(this).find(rel);

        restoreImage(component);
        clearValue(component);
        toggleRevertButton(component, false);
    });

    $(document).on("coral-fileupload:fileadded", ".cq-wcm-pagethumbnail .cq-wcm-fileupload", function(e) {
        var fileUploadEl = $(this);
        var fileUpload = e.originalEvent.target;
        var file = e.originalEvent.detail.item.file;
        var component = fileUploadEl.closest(".cq-wcm-pagethumbnail");

        wait(component);

        // use attr() instead of prop() for action, so that no domain is appended
        var base = component.closest("form").attr("action");

        fileUploadEl
            .one("fileuploadload", function(e) {
                var status = $(e.content).find("#Status").text();
                e.fileUpload._internalOnUploadLoad(e, e.item, status, e.content);
            })
            .one("coral-fileupload:load", function(e) {
                var url = base + (function() {
                    var name = fileUpload.name;
                    if (name.indexOf(".") === 0) {
                        name = name.substring(1);
                    }
                    return name;
                })();

                clearWait(component, url + "?ck=" + new Date().getTime());
                fileUploadEl.removeClass("disabled");
                setValue(component, fileUpload.name.replace(".sftmp", "@MoveFrom"), url);
            });


        fileUpload.action = base;
        fileUpload.upload(file.name);

        return true;
    });


    function generate(component) {
        var activator = component.find(".cq-wcm-pagethumbnail-activator").prop("disabled", true);
        wait(component);

        var path = component.data("cqWcmPagethumbnailPath");
        var isTemplate = component.data("isTemplate") || false;
        var dest = isTemplate ? "thumbnail.png.sftmp" : "file.sftmp";

        var pgen = new CQ.Siteadmin.PagePreview();
        pgen.generatePreview(path, dest, isTemplate, function(data) {
            // use attr() instead of prop() for action, so that no domain is appended
            if(isTemplate) {
                setValue(component, "./thumbnail.png@MoveFrom", component.closest("form").attr("action") + "/" + dest);
            } else {
                setValue(component, "./image/file@MoveFrom", component.closest("form").attr("action") + "/image/" + dest);
            }
            clearWait(component, data);
            activator.prop("disabled", false);
        });
    }

    function wait(component) {
        ui.wait(component.find(".cq-wcm-pagethumbnail-image").parent()[0]);
    }

    function clearWait(component, src) {
        var original = component.find(".cq-wcm-pagethumbnail-image");

        if (original.length) {
            component.data("cq-wcm-pagethumbnail.internal.original", original);
        }

        original.replaceWith($('<img class="cq-wcm-pagethumbnail-image">').prop("src", src));

        toggleRevertButton(component, true);

        ui.clearWait();
    }

    function restoreImage(component) {
        component.find(".cq-wcm-pagethumbnail-image").replaceWith(component.data("cq-wcm-pagethumbnail.internal.original"));
    }

    function toggleRevertButton(component, show) {
        component.find('button[type="reset"]')[0].hidden = !show;
    }

    function setValue(component, name, url, isTemplate) {
        var hidden,
            hiddenDelete,
            isTemplate = typeof isTemplate !== 'undefined' ? isTemplate : false;

        hidden = component.find("input[name=\"" + name + "\"]");
        hiddenDelete = component.find(".cq-wcm-pagethumbnail-hidden-delete");

        if (hidden.length == 0) {
            hidden = component.find(".cq-wcm-pagethumbnail-hidden");

            if (!hidden.length) {
                hidden = $('<input class="cq-wcm-pagethumbnail-hidden" type="hidden">').appendTo(component);
            }
        }

        if(hiddenDelete.length == 0 && name.match("fileReference$")) {
            if (isTemplate) {
                $('<input class="cq-wcm-pagethumbnail-hidden-delete" type="hidden" name="./thumbnail.png@Delete" value="">').appendTo(component);
            } else {
                $('<input class="cq-wcm-pagethumbnail-hidden-delete" type="hidden" name="./image/file@Delete" value="">').appendTo(component);
            }
        } else {
            hiddenDelete.remove();
        }

        hidden.prop("name", name).val(url.replace(new RegExp("^" + contextPath), "").replace("_jcr_content", "jcr:content")).prop("disabled", false);
    }

    function clearValue(component) {
        component.find(".cq-wcm-pagethumbnail-hidden").remove();
    }

    $(document).on("click", ".cq-wcm-pagethumbnail-activator", function(e) {
        generate($(this).closest(".cq-wcm-pagethumbnail"));
    });

    $(document).on("cq-assetpicker", ".cq-wcm-pagethumbnail", function(e) {
        var component = $(e.target);
        var isTemplate = component.data("isTemplate") || false;
        if (isTemplate) {
            setValue(component, "./jcr:content/fileReference", e.path, true);
        } else {
            setValue(component, "./image/fileReference", e.path);
        }

        clearWait(component, e.path);
    });

    function showAssetPicker() {
        var href = Granite.HTTP.externalize("/aem/assetpicker")
            + "?mode=single"
            + "&type=image",
            $iframe = $('<iframe class="cq-AssetPicker cq-AssetPicker-iframe"></iframe>'),
            $modal = $('<div class="cq-AssetPicker cq-AssetPicker-modal coral-Modal"></div>');

        $iframe.attr("src", href).appendTo($modal);

        $modal.appendTo("body").modal({
            type: "default",
            buttons: [],
            visible: true
        });
        return $modal;
    }

    /**
     * Receive two-part messages from the AssetPicker dialog.  The "data" part indicates the
     * asset picker path should be updated; the "config" part indicates whether or not the
     * dialog should be closed.
     */
    function receiveMessage(event) {
        if (event.origin !== location.origin) {
            return;
        }
        if (!$assetPicker || !$pageThumbnail) {
            return;
        }

        var fromDam = JSON.parse(event.data);

        if (fromDam.data) {
            var path = fromDam.data[0].path;
            $pageThumbnail.trigger({
                type: 'cq-assetpicker',
                path: path
            });
        }

        if (fromDam.config) {
            var configFromDam = fromDam.config;
            if (configFromDam.action === 'close' || configFromDam.action === 'done') {
                $assetPicker.data("modal").hide();
            }
        }
    }

    window.addEventListener("message", receiveMessage, false);

    $(document).on("click", rel + " .js-browse-activator", function (e) {
        $pageThumbnail = $(e.target).closest(rel);
        $assetPicker = showAssetPicker();
    });

})(window, document, Granite, Granite.$);