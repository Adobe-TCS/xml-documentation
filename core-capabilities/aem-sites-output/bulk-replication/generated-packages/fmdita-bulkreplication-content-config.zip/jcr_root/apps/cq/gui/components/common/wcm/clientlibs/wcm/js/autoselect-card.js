/*
 * ADOBE CONFIDENTIAL
 *
 * Copyright 2014 Adobe Systems Incorporated
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and may be covered by U.S. and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 */
(function(window, document, Granite, $) {
    "use strict";
    
    // @badpractice This code assume and use many internal details, which may not work anymore.
    // Please DO NOT follow this approach.
    
    // @deprecated Reading the URL of a page and doing an action need to be done by page/shell level clientlib, instead of "cq.common.wcm".
    // Otherwise it is just too opinionated and may interfere wrongly.

    // TODO: make it generic so that it's not specific to Sites
    $(document).on("foundation-contentloaded", function(e) {
        if (window.location.hash && window.location.hash !== '') {
            var doc = $(document),
                path = window.location.hash.substring(1),
                $item = $(".foundation-collection-item[data-path=\"" + path + "\"]");

            if ($item.length > 0) {
                $(doc).trigger('foundation-mode-change', ['selection', 'cq-siteadmin-admin-childpages']);

                if (CUI && CUI.ColumnView && $.cookie('cq.sites.childpages.layoutId') === 'columns') {
                    // Column view
                    var columnView = $(".foundation-collection").data('foundation-layout-columns.internal.ColumnView');
                    if (columnView) {
                        // trigger selection manually as foundation-selections adapter has not fully
                        // been implemented for column views yet
                        $(".coral-ColumnView-icon", $item).click();
                    }
                } else {
                    // Card and List views
                    var foundationSelections = $(".foundation-collection").adaptTo("foundation-selections");
                    foundationSelections.select($item);
                }
            }

            window.location.hash = '';
        }
    });

})(window, document, Granite, Granite.$);
