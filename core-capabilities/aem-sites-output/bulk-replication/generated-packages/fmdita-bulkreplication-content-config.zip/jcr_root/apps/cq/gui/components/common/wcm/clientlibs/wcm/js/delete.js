/*
 * ADOBE CONFIDENTIAL
 *
 * Copyright 2014 Adobe Systems Incorporated
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and may be covered by U.S. and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 */
(function(window, document, $, Granite) {
    "use strict";

    var COMMAND_URL= Granite.HTTP.externalize("/bin/wcmcommand");
    
    var deleteText;
    function getDeleteText() {
        if (!deleteText) {
            deleteText = Granite.I18n.get("Delete");
        }
        return deleteText;
    }
    
    var cancelText;
    function getCancelText() {
        if (!cancelText) {
            cancelText = Granite.I18n.get("Cancel");
        }
        return cancelText;
    }

    function deletePages(collection, paths, force, checkChildren) {
        var ui = $(window).adaptTo("foundation-ui");
        ui.wait();

        $.ajax({
            url: COMMAND_URL,
            type: "POST",
            data: {
                _charset_: "UTF-8",
                cmd: "deletePage",
                path: paths,
                force: !!force,
                checkChildren: !!checkChildren
            },
            success: function() {
                ui.clearWait();
                
                var api = collection.adaptTo("foundation-collection");
                var layoutConfig = collection.data("foundationLayout");

                // In column layout the collection id may represent a preview column belonging to a deleted item.
                if (layoutConfig && layoutConfig.layoutId === "column") {
                    var previewShown = $("coral-columnview-preview").length > 0;

                    if (previewShown) {
                      if (api && "load" in api) {
                        var id = paths[0];

                        if (id) {
                          var parentId = id.substring(0, id.lastIndexOf('/')) || '';

                          if (parentId != '') {
                            api.load(parentId);
                          }
                        }
                      }
                    }

                    Coral.commons.nextFrame(function() {
                        if (api && "reload" in api) {
                            api.reload();
                        }
                    });

                    return;
                }

                if (api && "reload" in api) {
                    api.reload();
                    return;
                }

                var contentApi = $(".foundation-content").adaptTo("foundation-content");
                if (contentApi) {
                    contentApi.refresh();
                }
            },
            error: function(xhr) {
                ui.clearWait();

                var message = Granite.I18n.getVar($(xhr.responseText).find("#Message").html());

                if (xhr.status == 412) {
                    ui.prompt(getDeleteText(), message, "notice", [{
                        text: getCancelText()
                    }, {
                        text: Granite.I18n.get("Force Delete"),
                        warning: true,
                        handler: function() {
                            deletePages(collection, paths, true);
                        }
                    }]);
                    return;
                }

                ui.alert(Granite.I18n.get("Error"), message, "error");
            }
        });
    }
    
    function createEl(name) {
        return $(document.createElement(name));
    }

    $(window).adaptTo("foundation-registry").register("foundation.collection.action.action", {
        name: "cq.wcm.delete",
        handler: function(name, el, config, collection, selections) {
            var message = createEl("div");

            var intro = createEl("p").appendTo(message);
            if (selections.length === 1) {
                intro.text(Granite.I18n.get("You are going to delete the following item:"));
            } else {
                intro.text(Granite.I18n.get("You are going to delete the following {0} items:", selections.length));
            }

            var list = [];
            var maxCount = Math.min(selections.length, 12);
            for (var i = 0, ln = maxCount; i < ln; i++) {
                var title = $(selections[i]).find(".foundation-collection-item-title").text();
                list.push(createEl("b").text(title).prop("outerHTML"));
            }
            if (selections.length > maxCount) {
                list.push("&#8230;"); // &#8230; is ellipsis
            }

            createEl("p").html(list.join("<br>")).appendTo(message);

            var ui = $(window).adaptTo("foundation-ui");
            
            ui.prompt(getDeleteText(), message.html(), "notice", [{
                text: getCancelText()
            }, {
                text: getDeleteText(),
                warning: true,
                handler: function() {
                    var paths = selections.map(function(v) {
                        return $(v).data("foundationCollectionItemId");
                    });

                    deletePages($(collection), paths, false, true);
                }
            }]);
        }
    });
})(window, document, Granite.$, Granite);
