/*
 * ADOBE CONFIDENTIAL
 *
 * Copyright 2012 Adobe Systems Incorporated
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and may be covered by U.S. and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 */

(function(window, document, $, URITemplate) {
    
    // @badpractice This code assume specific fields and out of scope UX (e.g. Create popover).
    
    // @deprecated Because of the problem above, it is hard to reuse this for other scenario. 
    // Please use `foundation.dialog` as the action to show a dialog instead.

    // id of the modal form
    var modal = "#create-folder-modal";

    // foundation-collection-action path
    var actionPath = null;

    $(window).adaptTo("foundation-registry").register("foundation.collection.action.action", {
        name: "cq.wcm.createfolder",
        handler: function(name, el, config, collection, selections) {
            if (!selections.length) return;

            actionPath = URITemplate.expand(config.data.action, {
                item: $(selections[0]).data("foundationCollectionItemId")
            });
            $(modal).modal("show");
        }
    });

    $(document).on("beforeshow", modal, function () {
        // hide "Create" popover
        $(".coral-Popover:visible").popover("hide");
        // reset form (textfields and checkboxes)
        $(".coral-Textfield", modal).each(function () {
            $(this).val("");
        });
        $(".coral-Checkbox-input", modal).each(function () {
            $(this).prop("checked", $(this).attr("checked") == "checked");
        });
    });

    $(document).on("submit", modal, function (e) {
        e.preventDefault();
        var $modal = $(modal);
        $modal.modal("hide");
        // copy 'title' to 'nameHint' if no 'nameHint' has been provided
        var $title = $("input[name='./jcr:title']", $modal);
        var $nameHint = $("input[name=':nameHint']", $modal);
        if (!$nameHint.val()) {
            $nameHint.val($title.val());
        }
        var url;
        if (actionPath) {
            url = actionPath;
        } else {
            url = $modal.attr("action") + "/";
        }
        $.ajax({
            method: "post",
            url: Granite.HTTP.externalize(url),
            data: $modal.serialize()
        }).done(function (data, textStatus, jqXHR) {
            $modal.remove();
            var content = $(".foundation-content").adaptTo("foundation-content");
            content.refresh();
        }).fail(function (jqXHR) {
            var message = $("#Message", jqXHR.responseText).text();
            var ui = $(window).adaptTo("foundation-ui");
            ui.alert(Granite.I18n.get("Error"), message, "error");
        });
        actionPath = null;
    });


})(window, document, Granite.$, Granite.URITemplate);