/*
 * ADOBE CONFIDENTIAL
 *
 * Copyright 2014 Adobe Systems Incorporated
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and may be covered by U.S. and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 */
(function(document, Granite, $) {
    "use strict";
    
    var configs = {
        lock: {
            cmd: "lockPage"
        },
        unlock: {
            cmd: "unlockPage"
        }
    };

    var lockActionRelation = "cq-siteadmin-admin-actions-lockpage-activator";
    var unlockActionRelation = "cq-siteadmin-admin-actions-unlockpage-activator";

    function setLockStatus(path, action, collection, selection) {
        var config = configs[action];
        
        var ui = $(window).adaptTo("foundation-ui");
        ui.wait();
        
        $.ajax({
            url: Granite.HTTP.externalize("/bin/wcmcommand"),
            type: "POST",
            data: {
                _charset_: "UTF-8",
                path: path,
                cmd: config.cmd
            }
        }).done(function() {
            ui.clearWait();
            
            var api = collection.adaptTo("foundation-collection");
            if (api && "reload" in api) {
                api.reload();
                /**
                 * Related to @GRANITE-10881 the selected page gets not updated in the colmn view.
                 * Hence we have to update the locking relation manually and refresh the action bar.
                 */
                if(collection.is('coral-columnview')) {
                    updateLockingRelationInSelection(action, selection);
                    collection.trigger("foundation-selections-change");
                }
                return;
            }
            
            var contentApi = $(".foundation-content").adaptTo("foundation-content");
            if (contentApi) {
                contentApi.refresh();
            }
        }).fail(function(xhr) {
            ui.clearWait();
            
            var title = Granite.I18n.get("Error");
            var message = Granite.I18n.getVar($(xhr.responseText).find("#Message").html());
            ui.alert(title, message, "error");
        });
    }

    function updateLockingRelationInSelection(action, selection) {
        var quickActions = $(selection).find(".foundation-collection-quickactions");
        var relations = $(quickActions).data("foundationCollectionQuickactionsRel") || "";
        relations = action === "lock" ? relations.replace(lockActionRelation, unlockActionRelation) : relations.replace(unlockActionRelation, lockActionRelation);
        $(quickActions).data("foundationCollectionQuickactionsRel", relations);
    }

    var registry = $(window).adaptTo("foundation-registry");

    registry.register("foundation.collection.action.action", {
        name: "cq.wcm.lock",
        handler: function(name, el, config, collection, selections) {
            var path = $(selections[0]).data("foundationCollectionItemId");
            setLockStatus(path, "lock", $(collection), $(selections[0]));
        }
    });
    
    registry.register("foundation.collection.action.action", {
        name: "cq.wcm.unlock",
        handler: function(name, el, config, collection, selections) {
            var path = $(selections[0]).data("foundationCollectionItemId");
            setLockStatus(path, "unlock", $(collection), $(selections[0]));
        }
    });
})(document, Granite, Granite.$);
