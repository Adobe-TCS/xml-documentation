/*
 ADOBE CONFIDENTIAL

 Copyright 2014 Adobe Systems Incorporated
 All Rights Reserved.

 NOTICE:  All information contained herein is, and remains
 the property of Adobe Systems Incorporated and its suppliers,
 if any.  The intellectual and technical concepts contained
 herein are proprietary to Adobe Systems Incorporated and its
 suppliers and may be covered by U.S. and Foreign Patents,
 patents in process, and are protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material
 is strictly forbidden unless prior written permission is obtained
 from Adobe Systems Incorporated.
 */
(function(window, document, $, URITemplate) {
    var replicateURL = Granite.HTTP.externalize("/bin/replicate");
    var successMessage = Granite.I18n.get("The item has been published");

    $(window).adaptTo("foundation-registry").register("foundation.collection.action.action", {
        name: "cq.wcm.publish",
        handler: function(name, el, config, collection, selections) {
            var ui = $(window).adaptTo("foundation-ui");
            ui.wait();

            var paths = selections.map(function(v) {
                var item = $(v);
                
                // allow to set user defined reference paths, split by comma
                var refPath = item.data("checkReferencesPath");
                if (!refPath) {
                    // coral3 selection is acting on the masonry level
                    refPath = item.children().data("checkReferencesPath");
                }

                if (refPath) {
                    return refPath.split(",");
                }
                
                return item.data("foundationCollectionItemId");
            });

            if (!paths.length) return;

            // flatten the array
            paths = [].concat.apply([], paths);

            var referencePromise = $.ajax({
                url: URITemplate.expand(config.data.referenceSrc, {
                    path: paths
                }),
                "type": "POST",
                cache: false,
                dataType: "json"
            });

            referencePromise.done(function(json) {
                if (json.assets.length === 0) {
                    // publish directly
                    $.ajax({
                        url: replicateURL,
                        type: "POST",
                        data: {
                            _charset_: "utf-8",
                            cmd: "Activate",
                            path: paths
                        }
                    }).always(function() {
                        ui.clearWait();
                    }).done(function() {
                        var api = $(collection).adaptTo("foundation-collection");
                        if (api && "reload" in api) {
                            api.reload();
                            ui.notify(null, successMessage);
                            return;
                        }
                        
                        var contentApi = $(".foundation-content").adaptTo("foundation-content");
                        if (contentApi) {
                            contentApi.refresh();
                        }

                        ui.notify(null, successMessage);
                    }).fail(function(xhr) {
                        var title = Granite.I18n.get("Error");
                        var message = Granite.I18n.getVar($(xhr.responseText).find("#Message").html());
                        ui.alert(title, message, "error");
                    });
                } else {
                    // redirect to wizard
                    sessionStorage.setItem("document.referrer", window.location.href);
                    
                    window.location.href = URITemplate.expand(config.data.wizardSrc, {
                        item: paths
                    });
                }
            });

            referencePromise.fail(function(xhr) {
                ui.clearWait();

                var title = Granite.I18n.get("Error");
                var message = Granite.I18n.get("Failed to retrieve references for selected items.");
                ui.alert(title, message, "error");
            });
        }
    });

    
    /**
     * On content load, display a notification in case we have been redirect from
     * the publish or unpublish page wizard.
     */
    $(document).on("foundation-contentloaded", function (e) {
        var message = sessionStorage.getItem("cq-page-published-message");
        if (message !== null) {
            sessionStorage.removeItem("cq-page-published-message");
            
            var ui = $(window).adaptTo("foundation-ui");
            ui.notify(null, Granite.I18n.getVar(message));
        }
    });
})(window, document, Granite.$, Granite.URITemplate);
