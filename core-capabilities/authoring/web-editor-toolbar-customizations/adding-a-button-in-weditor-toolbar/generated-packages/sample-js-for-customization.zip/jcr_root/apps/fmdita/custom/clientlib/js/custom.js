
 (function (document, $, ns) {
   "use strict";

$(document).ready(setTimeout(function() {
 fmxml.commandHandler.subscribe({
 key: 'custom.alert',
 next: function() {
 alert("XML Documentation solution version x.x")
 }
 })
}, 1000))

})(document, Granite.$, Granite.author);